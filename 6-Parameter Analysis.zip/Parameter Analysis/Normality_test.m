%% 1. Read the data in Excel
[data, ~, ~] = xlsread('data.xlsx', 1, 'I2:I31'); % 1=sheet1,A2:A31=Data range

% Data preprocessing: Remove NaN values to ensure the validity of the test.
data = data(~isnan(data)); 
fprintf('The amount of data read in：%d s\n', length(data));
if length(data) < 3 
error('The amount of data is insufficient. At least 3 pieces of data are required for the normality test.');
end

%% 2. Normality test
fprintf('\n========== Result of normality test ==========\n');

% Core method: Lilliefors test
[h1, p1] = lillietest(data); 
fprintf('1. Lilliefors Normality test (core)：\n');

if h1 == 0
fprintf(' Test result: The data conforms to a normal distribution.\n');
else
fprintf(' Test result: The data does not follow a normal 			distribution.\n');
end
fprintf(' p-value：%.4f (Judgment rule: If p ≥ 0.05, it indicates that the 			data follows a normal distribution.) \n', p1);

%% 3. Visual verification
figure('Position', [100, 100, 700, 500]);
set(gcf, 'Color', 'white'); 

% Subfigure 1: Histogram + Normal Fit Curve
subplot(2,1,1);
histfit(data, 10);
% Enhance the graphics
xlabel('Numerical value', 'FontName', 'Times New Roman', 'FontSize', 12);
ylabel('Frequency', 'FontName', 'Times New Roman', 'FontSize', 12);
title('Data histogram + Normal distribution fitting curve', 'FontName', 'Times New Roman', 'FontSize', 13);
grid on;
set(gca, 'FontName', 'Times New Roman', 'FontSize', 11);

% Subfigure 2: Q-Q Plot
subplot(2,1,2);
qqplot(data);
title('Q-Q plot (normality verification)', 'FontName', 'Times New Roman', 'FontSize', 13);
xlabel('Standard normal quantile', 'FontName', 'Times New Roman', 'FontSize', 12);
ylabel('Data quantile', 'FontName', 'Times New Roman', 'FontSize', 12);
grid on;
set(gca, 'FontName', 'Times New Roman', 'FontSize', 11);

%% 4. Output data statistical characteristics
mu = mean(data);
sigma = std(data);
skew_val = skewness(data);
kurt_val = kurtosis(data);

fprintf('\n========== Data statistical characteristics ==========\n');
fprintf('Mean value：%.4f (The center position of the normal...
distribution)\n',mu);
fprintf('Standard Deviation: %.4f(Discreteness of normal distribution)) 			\n', sigma);
fprintf('Skewness: %.4f(Normal distribution skewness ≈ 0, the closer to 0,... 			the more appropriate)\n', skew_val);
fprintf('Kurtosis：%.4f (The kurtosis of the normal distribution ≈ 3. The... 			closer it is to 3, the more it conforms to the normal distribution.) 			\n',  kurt_val);

% Additional Explanation
fprintf('\n========== Result Interpretation ==========\n');
fprintf('1. Core judgment: Based on the p-value from the Lilliefors test... 			(p ≥ 0.05 indicates normal distribution);\n');
fprintf('2. Graphical Aid: The closer the points in the Q-Q plot are to the... 			straight line, and the more the histogram resembles a bell shape,... 			the more it conforms to a normal distribution.\n');
fprintf('3. Statistical characteristics: Skewness ≈ 0, Kurtosis ≈ 3, ...
used to assist in verifying normality.\n');