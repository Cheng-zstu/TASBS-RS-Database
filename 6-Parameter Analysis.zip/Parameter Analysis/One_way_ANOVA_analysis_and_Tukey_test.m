%% 1. Read data
[data_raw, ~, ~] = xlsread('data.xlsx', 1, 'A2:H31');

% Data cleaning
data = data_raw;
for col = 1:size(data,2)
col_data = data(:,col);
col_mean = mean(col_data(~isnan(col_data)));
col_data(isnan(col_data)) = col_mean;
data(:,col) = col_data;
end

%% 2. Format for ANOVA analysis
[n_rows, n_groups] = size(data); % n_rows=30, n_groups=8
response = data(:);
group = repelem(1:n_groups, n_rows);

%% 3. One-way ANOVA analysis
[p_val, anova_tbl, stats] = anova1(response, group, 'off');

fprintf('===== The ANOVA analysis results of 8 algorithms ====\n');
fprintf('Overall p-value: %.6f (If p < 0.05, it indicates a significant... 			difference between the algorithms)\n', p_val);
fprintf('ANOVA detailed table：\n');
disp(anova_tbl);

%% 4. Tukey HSD Multiple Comparison Test
fprintf('\n========== Tukey HSD multiple comparison results ==========\n');

[c, m, h, nms] = multcompare(stats, 'CType', 'tukey-kramer', 'Display', 'off');

% Algorithm tag
algo_names = {'DQN','DDPG','SA','GA','MBO','CCMBO','EMBO','MBO-HSA'};

% Output the means and standard errors of each group
fprintf('\nThe average values of each algorithm (±SE) ：\n');
fprintf('%-10s %10s %10s\n', 'Algorithm', 'Mean value', 'Standard deviation');
for i = 1:n_groups
fprintf('%-10s %10.4f %10.4f\n', algo_names{i}, m(i,1), m(i,2));
end

% Output the result table showing pairwise comparisons
fprintf('\nTukey HSD Pairwise comparison (significant differences),...
p<0.05) ：\n');
fprintf('%-10s %-10s %12s %12s %12s %10s %8s\n', ...
'Group A', 'Group B', 'Mean difference', 'Lower bound of CI',...
 'Upper bound of CI', 'p-value', 'Remarkable');

sig_count = 0;
for i = 1:size(c,1)
gi = c(i,1); gj = c(i,2);
diff_mean = c(i,4);
ci_lo = c(i,3);
ci_hi = c(i,5);
p_pair = c(i,6);
sig_str = '';
if p_pair < 0.001
sig_str = '***';
elseif p_pair < 0.01
sig_str = '**';
elseif p_pair < 0.05
sig_str = '*';
end
if p_pair < 0.05
sig_count = sig_count + 1;
fprintf('%-10s %-10s %12.4f %12.4f %12.4f %10.4f %8s\n', ...
algo_names{gi}, algo_names{gj}, diff_mean, ci_lo, ci_hi,...
 p_pair, sig_str);
end
end

if sig_count == 0
fprintf('(Algorithms without significant differences)\n');
end

% Output all comparison results
fprintf('\nThe results of all pairwise comparisons:\n');
fprintf('%-10s %-10s %12s %12s %12s %10s %8s\n', ...
'Group A', 'Group B', 'MD', 'Lb of CI', 'Ub of CI', 'p-value', 'Remarkable');
for i = 1:size(c,1)
gi = c(i,1); gj = c(i,2);
diff_mean = c(i,4);
ci_lo = c(i,3);
ci_hi = c(i,5);
p_pair = c(i,6);
sig_str = '';
if p_pair < 0.001, sig_str = '***';
elseif p_pair < 0.01, sig_str = '**';
elseif p_pair < 0.05, sig_str = '*';
end
fprintf('%-10s %-10s %12.4f %12.4f %12.4f %10.4f %8s\n', ...
algo_names{gi}, algo_names{gj}, diff_mean, ci_lo, ci_hi, ...
p_pair, sig_str);
end

%% 5. Visualization: Mean Comparison Graph
figure('Name','Tukey HSD Mean comparison');
errorbar(1:n_groups, m(:,1), m(:,2)*1.96, 'o-', 'LineWidth', 1.5, ...
'MarkerSize', 8, 'MarkerFaceColor', 'auto', 'CapSize', 8);
set(gca, 'XTick', 1:n_groups, 'XTickLabel', algo_names, 'FontSize', 12);
xlabel('Algorithm', 'FontSize', 13);
ylabel('Mean (±95% CI)', 'FontSize', 13);
title('Comparison of the means of each algorithm (Tukey HSD)', 'FontSize',... 		14);
grid on;